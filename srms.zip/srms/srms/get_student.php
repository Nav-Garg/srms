<?php
include('includes/config.php');
if(!empty($_POST["courseid"])) 
{
 $cid=intval($_POST['courseid']);
 if(!is_numeric($cid)){
 
 	echo htmlentities("invalid Course");exit;
 }
 else{
 $stmt = $dbh->prepare("SELECT StudentName,StudentId FROM tblstudents WHERE Courseid= :id order by StudentName");
 $stmt->execute(array(':id' => $cid));
 ?><option value="">Select Category </option><?php
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {
  ?>
  <option value="<?php echo htmlentities($row['StudentId']); ?>"><?php echo htmlentities($row['StudentName']); ?></option>
  <?php
 }
}

}
// Code for Subjects
if(!empty($_POST["courseid1"])) 
{
 $cid1=intval($_POST['courseid1']);
 if(!is_numeric($cid1)){
 
  echo htmlentities("invalid Course");exit;
 }
 else{
 $status=0;	
 $stmt = $dbh->prepare("SELECT tblsubjects.SubjectName,tblsubjects.id FROM tblsubjectcombination join  tblsubjects on  tblsubjects.id=tblsubjectcombination.SubjectId WHERE tblsubjectcombination.CourseId=:cid and tblsubjectcombination.status!=:stts order by tblsubjects.SubjectName");
 $stmt->execute(array(':cid' => $cid1,':stts' => $status));
 
 while($row=$stmt->fetch(PDO::FETCH_ASSOC))
 {?>
  <p> <?php echo htmlentities($row['SubjectName']); ?><input type="text"  name="marks1[]" value="" class="form-control" required="" placeholder="Enter marks out of 75" autocomplete="off">
  	<br>
  	<input type="text"  name="marks2[]" value="" class="form-control" required="" placeholder="Enter marks out of 25" autocomplete="off"></p>
  
<?php  }
}
}


?>

<?php

if(!empty($_POST["studcourse"])) 
{
 $id= $_POST['studcourse'];
 $dta=explode("$",$id);
$id=$dta[0];
$id1=$dta[1];
 $query = $dbh->prepare("SELECT StudentId,Courseid FROM tblresult WHERE StudentId=:id1 and Courseid=:id ");
//$query= $dbh -> prepare($sql);
$query-> bindParam(':id1', $id1, PDO::PARAM_STR);
$query-> bindParam(':id', $id, PDO::PARAM_STR);
$query-> execute();
$results = $query -> fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query -> rowCount() > 0)
{ ?>
<p>
<?php
echo "<span style='color:red'> Result Already Declare .</span>";
 echo "<script>$('#submit').prop('disabled',true);</script>";
 ?></p>
<?php }


  }?>


